# Snake_Game
This is the classic Snake Game made using Python.

Copy the code in main.py and run it on your local machine. Don't forget to install tkinter module if you haven't already.

For installing the Tkinter module you can use any of the following commands : 
  
    1. sudo apt-get install python-tk
               OR
    2. pip install python-tk

ScreenCast : 

![](Snake_Game.gif)

I hope you enjoy playing the game :)
