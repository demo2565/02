# python-tkinter-project-ticket-booking
A Tkinter Project for airticket booking using Python
You should have mysql in your PC to execute the program

Go CMD and execute these commands:
1. pip install PIL

2.pip install mysql-connector-python

You have to create databases in myql as per requirements.
Database name: triplife

table1: details

table2: payment

#create tables accordingly given in the database() function
#save all the files in one folder and run triplife.py file.

ALL THE BEST
@andrewgeeks
