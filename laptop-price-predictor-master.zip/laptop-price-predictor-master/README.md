# laptop-price-predictor
Helps to predict laptop price using logistic regression.

Logistic regression is a statistical model that in its basic form uses a logistic function to model a binary dependent variable, although many more complex extensions exist.

The price is predicted by inputing features like graphics size,hard disk size, core generation etc.

The dataset of laptop pricing data is available.

NB: We have taken the price of laptops having intel cores only!

Thanks to <https://www.amazon.in/> for pricing data.

Instagram: <https://www.instagram.com/_andrewgeeks/>

Twitter: <https://twitter.com/andrewissac20>
