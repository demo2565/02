# This is not used in the game but provide an alternative approach 
# Alternatively you can write it as a class
# but will need to call the object  for example :
#  for example info_crit=List()in goblin.py
# and to call list you need to write  info_crit.foodlist 


class List:
    def __init__(self):
        self.foodlist=("Happy Mushrooms","Bony Bones","Rotten Apples","Mystery Meat")
        self.enemylist=("Tiny Tiny Dragon","Beta Male Orc","Hobbit Berserker","Tiny Tiny Dragon","Sucidal Jester","Cannibal Gnome")
        self.lootlist=("Fish Bone","Dirty Potato Sack","Fist Full of Straws","Wood Stick","Giant Boot","Rusty Umbrella")

 
