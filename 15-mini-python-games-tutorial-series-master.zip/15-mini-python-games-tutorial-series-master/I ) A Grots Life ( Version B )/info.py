
foodlist=("Happy Mushrooms","Bony Bones","Rotten Apples","Mystery Meat")
enemylist=("Tiny Tiny Dragon","Beta Male Orc","Hobbit Berserker","Tiny Tiny Dragon","Sucidal Jester","Cannibal Gnome")
lootlist=("Fish Bone","Dirty Potato Sack","Fist Full of Straws","Wood Stick","Giant Boot","Rusty Umbrella")

 
