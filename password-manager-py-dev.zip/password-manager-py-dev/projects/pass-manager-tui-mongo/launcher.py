from scripts.ui_handler import UiHandler

if __name__ == '__main__':
    ui_obj = UiHandler()
    ui_obj.login_client()
