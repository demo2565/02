from scripts import ui

ui_obj = ui.UI()
