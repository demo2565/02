# Demo of the projects:

<details open>
<summary>Choose a project!</summary>

1. [Tk-Encrypted](#tk-encrypted)
2. [Tui-Mongo](#tui-mongo)

</details>

## TK-ENCRYPTED:
### The Tkinter-based, encrypted-files driven password manager.
![TK demo gif](res/gifs/tk-encrypted.gif)

## TUI-MONGO:
### The Tui-based, mongo driven password manager.
![TUI demo gif](res/gifs/tui-mongo.gif)