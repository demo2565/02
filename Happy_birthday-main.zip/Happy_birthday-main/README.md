# Happy_birthday
<p align="center">
    <img src="https://github.com/Ananya-0306/Happy_birthday/blob/main/happy-birthday-gif-images-wallpapers-2017.gif" alt="Github Swag" />
</p>
Wish your friend Happy birthday using python
