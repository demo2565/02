from tkinter import *
import tkinter as tk
root = tk.Tk()
root.title('Instagram')

#iconbitmap() method is used to set the icon in a GUI window.
root.iconbitmap(r'C:\Users\USER\Desktop\instagram.ico')

root.mainloop()
