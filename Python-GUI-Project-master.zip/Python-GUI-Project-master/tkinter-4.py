import tkinter as tk

root = tk.Tk()
root.title("My Gui")
root.geometry("250x150")

#changing bg value
root['bg'] = "cyan"

root.mainloop()
