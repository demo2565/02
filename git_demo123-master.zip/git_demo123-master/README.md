# this is my first repo

## using for git demonstration 

hello i am a new user **learning about** git 

## Git 

* Initlize a folder as a git repo using
	* git init . 
* Git status to check your file status or working tree
	* git status 
* Use this command to add files into tracked section 
	* git add filename 
	* git add \*.py all python files 
	* git add -A # to add all files
* Create a snapshot using this command 
	* git commit -m "changes specific text"  
