# QRCode_Generator

This project helps to generate QR code for the given details.<br>

When you insert your details into the GUI and click on Generate QR, then the preview of generated QR code is shown at right part of GUI and the QR code gets saved in the file named QR.

### Steps to run the file:

1. Download the requirements. Open CMD and execute the following commands:
  ```
  pip install qrcode
  ```
  ```
  pip install python-resize-image
  ```
  ```
  pip install Pillow
  ```
  ```
  pip install tk
  ```
  ```
  pip install tk-tools
  ```
2. Run the python file.
3. Enter your details
4. Click on Generate QR
