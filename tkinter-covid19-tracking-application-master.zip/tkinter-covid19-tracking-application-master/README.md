# tkinter-covid19-tracking-application
This python tkinter application helps to track the covid19 status around the world!

Thanks for the covid library

Go to cmd and type: 'pip install covid'

Libraries Used: Tkinter and covid

Instagram: https://www.instagram.com/_andrewgeeks/

Twitter: https://twitter.com/andrewissac20
