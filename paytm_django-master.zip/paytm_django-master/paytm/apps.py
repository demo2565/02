from django.apps import AppConfig


class PaytmConfig(AppConfig):
    name = 'paytm'
