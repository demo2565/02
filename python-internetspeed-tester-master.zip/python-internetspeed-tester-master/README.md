# python-internetspeed-tester
A python file which helps to test your internet speed
Before running the script, run the below command in your cmd.
# pip install speedtest-cli

Have Fun^^^

Instagram: <https://www.instagram.com/_andrewgeeks/>

Twitter: <https://twitter.com/andrewissac20>
