Voice Calls
===========

Both private voice calls and group voice calls are currently supported by third-party libraries that integrate with
Pyrogram.

Libraries
---------

There are currently two main libraries (with very similar names) you can use:

1. https://github.com/pytgcalls/pytgcalls
2. https://github.com/MarshalX/tgcalls

Older implementations
---------------------

An older implementation of Telegram voice calls can be found at https://github.com/bakatrouble/pylibtgvoip (currently
outdated due to the deprecation of the Telegram VoIP library used underneath).